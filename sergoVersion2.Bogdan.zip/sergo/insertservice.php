<?php
include 'includes/server.php';
 
// Escape user inputs for security
$first_name = mysqli_real_escape_string($link, $_REQUEST['first_name']);
$last_name = mysqli_real_escape_string($link, $_REQUEST['last_name']);
$username = mysqli_real_escape_string($link, $_REQUEST['username']);
$sp_profession = mysqli_real_escape_string($link, $_REQUEST['sp_profession']);
$password = mysqli_real_escape_string($link, $_REQUEST['password']);
$password = md5($password);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);
$sp_email2 = mysqli_real_escape_string($link, $_REQUEST['sp_email2']);
$sp_phone = mysqli_real_escape_string($link, $_REQUEST['sp_phone']);
$sp_mobile = mysqli_real_escape_string($link, $_REQUEST['sp_mobile']);
$sp_mobile2 = mysqli_real_escape_string($link, $_REQUEST['sp_mobile2']);
 
$query="SELECT * FROM spinfo WHERE username='$username'";
$query2="SELECT * FROM spinfo WHERE email='$email'";
$result=mysqli_query($link,$query);
$result2=mysqli_query($link,$query2);
if(mysqli_num_rows($result)>=1)
{
	echo "Username already in use";
}
else if(mysqli_num_rows($result2)>=1)
{
	echo "Email already in use";
}
 else{
// Attempt insert query execution
$sql = "INSERT INTO spinfo (first_name, last_name, username, sp_profession, password, email,
							sp_email2, sp_phone, sp_mobile, sp_mobile2) 
		VALUES ('$first_name', '$last_name', '$username', '$sp_profession', '$password', '$email',
				'$sp_email2', '$sp_phone', '$sp_mobile', '$sp_mobile2')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
	
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 }
// Close connection
mysqli_close($link);
?>