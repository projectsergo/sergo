<!DOCTYPE html>
<head>
	<?php include 'includes/head.php';?>
</head>

<body>
	<!--- Include the Navigation Bar and Highlight Selection --->
	<?php $page = 'home'; include 'includes/navbar.php';?>

	<!--- First Container --->
	<div class="row mt-5">
		<div class="col-12 text-center mt-5">
			<h3>Home</h3>
		</div>
	</div>	
	<!--- First Container End --->
<h2 align="center">Bla bla search here </h2><br />
			 <div class="form-group">
				<div class="input-group">
				<h3><span class="badge badge-pill badge-primary">Search </span>&nbsp </h3>
					<input type="text" name="search_text" id="search_text" placeholder="Search by Ocupation or Area" class="form-control" />
					
				</div>
			
			</div>
			<br />
			
		<div id="result"> </div>
	<!--- Footer and Scripts Include --->
	<?php include 'includes/footer.php';?>
	<?php include 'includes/scripts.php';?>
	<?php include 'includes/connection.php';?>
	
	
	
</body>


<script>
$(document).ready(function(){
	load_data();
	function load_data(query)
	{
		$.ajax({
			url:"includes/connection.php",
			method:"post",
			data:{query:query},
			success:function(data)
			{
				$('#result').html(data);
			}
		});
	}
	$('#search_text').keyup(function(){
		var search = $(this).val();
		if(search != '')
		{
			load_data(search);
		}
		else
		{
		load_data();	
		}
	});

});
</script>