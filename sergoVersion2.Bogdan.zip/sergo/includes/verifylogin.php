<?php include 'includes/server.php';

session_start();
if($_SERVER['REQUEST_METHOD'] == "POST")
{
 //Username and Password sent from Form
 $username = mysqli_real_escape_string($link, $_POST['username']);
 $password = mysqli_real_escape_string($link, $_POST['password']);
 $password = md5($password);
 $sql = "SELECT * FROM userinfo WHERE username='$username' AND '$password'";
 $sql2 = "SELECT * FROM spinfo WHERE username='$username' AND '$password'";
 $query = mysqli_query($link, $sql);
 $query2 = mysqli_query($link, $sql2);
 $res=mysqli_num_rows($query);
 $res2=mysqli_num_rows($query2);
 
 
 
 //If result match $username and $password Table row must be 1 row
 if($res == 1)
 {	 
 $_SESSION ['userid']=$username;
 header("Location: enduserdash.php");
 }
 else
 {
	 if($res2 == 1)
	 {
		 $_SESSION ['userid']=$username;
		  header("Location: spdash.php");
	 }
	 else
	 {
		 echo "Invalid Username or Password";
	 }
	echo "Invalid Username or Password";
 }
}
?>