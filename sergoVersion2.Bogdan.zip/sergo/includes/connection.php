<?php
$connect = mysqli_connect("localhost", "root", "", "users");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
$query = "SELECT * FROM spinfo WHERE sp_profession LIKE '%".$search."%'OR sp_city LIKE '%".$search."%' ";
}
else
{
  ///$query = "SELECT * FROM spinfo ORDER BY id";
	return;
	
}

$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '<h4 align="center">Please select one of the members listed here :</h4>';
		
	$output .= '<div class="table-responsive">
					<table class="table table bordered">
						<tr>
							<th>First Name</th>
							<th>Last Name</th>
							<th>Profession</th>
							<th>Mobile</th>
							<th>City</th>
						</tr>';
	while($row = mysqli_fetch_array($result))
	{
		$output .= '
			<tr>
				<td>'.$row["first_name"].'</td>
				<td>'.$row["last_name"].'</td>
				<td>'.$row["sp_profession"].'</td>
				<td>'.$row["sp_mobile"].'</td>
				<td>'.$row["sp_city"].'</td>
			</tr>
		';
	}
	echo $output;
}
else
{
	echo 'Please type an Ocupation or the area you looking for';
}
?>