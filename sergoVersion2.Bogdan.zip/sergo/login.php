<!DOCTYPE html>
<head>
	<?php include 'includes/head.php';?>
</head>

<body>

<?php include 'includes/server.php';
	include 'includes/verifylogin.php';
?>

	<!--- Include the Navigation Bar and Highlight Selection --->
	<?php $page = 'login'; include 'includes/navbar.php';?>

	<!--- First Container --->
	<div class="row mt-5">
		<div class="col-12 text-center mt-5">
			<h3>Login</h3>
		</div>
	</div>	
	<!--- First Container End --->

<h1>Login</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<label>Username</label>
<input type="text" name="username" required><br/><br/>
<label>Password</label>
<input type="password" name="password" required><br/><br/>
<input type="submit" name="submit" value="Login"><br/>
<p><a href="register.php">New User Register!</a></p>
</form>
<!--- Footer and Scripts Include --->
	<?php include 'includes/footer.php';?>
	<?php include 'includes/scripts.php';?>
</body>
