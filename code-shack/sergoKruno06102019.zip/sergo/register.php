<!DOCTYPE html>
<head>
	<?php include 'includes/head.php';?>
</head>

<body>
	<!--- Include the Navigation Bar and Highlight Selection --->
	<?php $page = 'register'; include 'includes/navbar.php';?>
	

	<!--- First Container --->
	<div class="row mt-5">
		<div class="col-12 text-center mt-5">
			<h3>Register</h3>
		</div>
	</div>	
	<!--- First Container End --->

	
	<form action="insert.php" method="post">
    <p>
        <label for="firstName">First Name:</label>
        <input type="text" name="first_name" id="firstName" required>
    </p>
    <p>
        <label for="lastName">Last Name:</label>
        <input type="text" name="last_name" id="lastName" required>
    </p>
    <p>
        <label for="userName">Username:</label>
        <input type="text" name="username" id="username" required>
    </p>
	    <p>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>
    </p>
	    <p>
        <label for="emailAddress">Email Address:</label>
        <input type="email" name="email" id="email" required>
    </p>
    <input type="submit" value="Submit">
	<p><a href="registerservice.php">Offering service? Click here to register!</a></p>
</form>
<!--- Footer and Scripts Include --->
	<?php include 'includes/footer.php';?>
	<?php include 'includes/scripts.php';?>
</body>