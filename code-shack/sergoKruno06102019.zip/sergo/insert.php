<?php
include 'includes/server.php';
 
// Escape user inputs for security
$first_name = mysqli_real_escape_string($link, $_REQUEST['first_name']);
$last_name = mysqli_real_escape_string($link, $_REQUEST['last_name']);
$username = mysqli_real_escape_string($link, $_REQUEST['username']);
$password = mysqli_real_escape_string($link, $_REQUEST['password']);
$password = md5($password);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);

$query="SELECT * FROM userinfo WHERE username='$username'";
$query2="SELECT * FROM userinfo WHERE email='$email'";
$result=mysqli_query($link,$query);
$result2=mysqli_query($link,$query2);
if(mysqli_num_rows($result)>=1)
{
	echo "Username already in use";
}
else if(mysqli_num_rows($result2)>=1)
{
	echo "Email already in use";
}
 else{
// Attempt insert query execution
$sql = "INSERT INTO userinfo (first_name, last_name, username, password, email) 
		VALUES ('$first_name', '$last_name', '$username', '$password', '$email')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
	header("Location: login.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 }
// Close connection
mysqli_close($link);
?>