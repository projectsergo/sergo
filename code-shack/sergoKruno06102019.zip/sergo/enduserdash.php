<!DOCTYPE html>
<head>
	<?php 
	include 'includes/head.php';
	include 'includes/server.php';
	include 'includes/verifylogin.php';

	?>
</head>
<body>
<?php
echo "Welcome "; 
echo $_SESSION ['userid'];
?>

</body>


