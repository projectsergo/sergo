<!DOCTYPE html>
<head>
	<?php include 'includes/head.php';?>
	<?php $page = 'register'; include 'includes/navbar.php';?>
</head>

<body>
	<!--- Include the Navigation Bar and Highlight Selection --->
	

	<!--- First Container --->
	<div class="row mt-5">
		<div class="col-12 text-center mt-5">
			<h3>Register your profession</h3>
		</div>
	</div>	
	<!--- First Container End --->

	<form action="insertservice.php" method="post">
    <p>
        <label for="firstName">First Name:</label>
        <input type="text" name="first_name" id="firstName" required>
    </p>
    <p>
        <label for="lastName">Last Name:</label>
        <input type="text" name="last_name" id="lastName" required>
    </p>
    <p>
        <label for="emailAddress">Username:</label>
        <input type="text" name="username" id="username" required>
    </p>
	<p>
        <label for="profession">Your Profession:</label>
        <input type="text" name="sp_profession" id="profession" required>
    </p>
	    <p>
        <label for="emailAddress">Password:</label>
        <input type="text" name="password" id="password" required>
    </p>
	    <p>
        <label for="emailAddress">Email Address:</label>
        <input type="text" name="email" id="email" required>
    </p>
	 <p>
        <label for="recoveryEmail">Recovery Email Address:</label>
        <input type="text" name="sp_email2" id="email2">
    </p>
    <p>
        <label for="phoneNo">Phone Number:</label>
        <input type="text" name="sp_phone" id="phoneNumber" required>
    </p>
    <p>
        <label for="mobileNo">Mobile Number:</label>
        <input type="text" name="sp_mobile" id="mobile">
    </p>
	    <p>
        <label for="mobileNo2">Second Mobile Number:</label>
        <input type="text" name="sp_mobile2" id="mobile2">
    </p>
	    
    <input type="submit" value="Submit">
	<p><a href="register.php">Looking for service? Click here to register!</a></p>
</form>

<!--- Footer and Scripts Include --->
	<?php include 'includes/footer.php';?>
	<?php include 'includes/scripts.php';?>
</body>