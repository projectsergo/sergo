<footer>
	<div class="container">
		<div class="row text-center py-5">
			<div class="col-md-4">
				<h3>SERGO</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
			</div>
			<div class="col-md-4">
				<h3 class="text-center">CONTACT INFO</h3><strong>Contact Info</strong>
				<p>(888) 888-8888<br>
				contact@sergo.com</p>
			</div>
			<div class="col-md-4 pb-5">
				<h3 class="text-center">CONNECT WITH US</h3><br>
				<a class="btn btn-outline-light btn-lg" href="mailto:project.sergo@gmail.com">SEND US AN EMAIL</a>
			</div>
		</div>
	</div>
</footer>